/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;


/**
 *
 * @author Juan Pablo
 */
public class Clientes {
private String nombre;
private String correoElectronico;
private String petición;
   public Clientes(String nombre, String correoElectronico, String petición) {
        this.nombre = nombre;
        this.correoElectronico = correoElectronico;
        this.petición = petición;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getPetición() {
        return petición;
    }

    public void setPetición(String petición) {
        this.petición = petición;
    }

}
