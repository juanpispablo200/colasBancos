/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.main;

import java.util.Scanner;

/**
 *
 * @author Juan Pablo
 */
public class ColaBancos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GestorClientess clientess = new GestorClientess();
        Scanner entradas = new Scanner(System.in);
         System.out.println("Ingresa tu nombre");
            String nombre=entradas.next();
            System.out.println("Ingresa tu correo");
            String ccorreoElectronico = entradas.next();
            System.out.println("Ingresa el motivo de tu consulta");
            String petición =entradas.next();
            clientess.llegadaCliente(new Clientes(nombre, ccorreoElectronico, petición));
    } 
    
}