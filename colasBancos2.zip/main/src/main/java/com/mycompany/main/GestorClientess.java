/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

/**
 *
 * @author Juan Pablo
 */
public class GestorClientess {
  private Queue<Clientes> colasClientes;
  private int clientesAtendidos;
    private int tiempoEsperaTotal;
    public void gestorCliente() {
        colasClientes = new LinkedList<>();
    }
    public void llegadaCliente(Clientes c) {
      colasClientes.add(c);
      String cliente = "Cliente " + (clientesAtendidos + 1);
        colasClientes.offer(c);
        System.out.println(cliente + " ha llegado al banco.");
        clientesAtendidos++;
    }
   public void atencionCliente() {
        System.out.println(colasClientes.element().toString());
        
         if (!colasClientes.isEmpty()) {
            Clientes cliente = colasClientes.poll();
            System.out.println(cliente + " está siendo atendido.");

            // Simular el tiempo de atención del cliente
            int tiempoAtencion = new Random().nextInt(6) + 1; 
            try {
                Thread.sleep(tiempoAtencion * 1000);  
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println(cliente + " ha sido atendido en " + tiempoAtencion + " minutos.");
            tiempoEsperaTotal += tiempoAtencion;
        }
    }
 
   
    }

